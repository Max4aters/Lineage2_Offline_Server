#!/bin/sh
java -Djava.util.logging.config.file=console.cfg -cp config/xml:./../libs/*:login.jar l2r.tools.gsregistering.GameServerRegister -c